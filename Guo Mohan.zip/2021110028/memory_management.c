#include "memory_management.h"

#define MAX_BLOCKS 1000

void init_mem_manager(MemoryManager *manager, size_t heap_size) {

    manager->heap_start = malloc(heap_size);
    if (!manager->heap_start) {
        printf("Heap allocation failed.\n");
        return;
    }
    manager->heap_end = (char *)manager->heap_start + heap_size;

    manager->blocks = (MemoryBlock *)malloc(MAX_BLOCKS * sizeof(MemoryBlock));
    if (!manager->blocks) {
        printf("Block array allocation failed.\n");
        return;
    }

    manager->blocks[0].address = manager->heap_start;
    manager->blocks[0].size = heap_size;
    manager->blocks[0].is_available = 1;

    manager->num_blocks = 1;
    manager->available_blocks = 1;
}

void *my_malloc(MemoryManager *manager, size_t size) {
    for (int i = 0; i < manager->num_blocks; i++) {
        if (manager->blocks[i].is_available && manager->blocks[i].size >= size) {
            manager->blocks[i].is_available = 0;
            manager->available_blocks--; // Reduce one available block

            // Carve up the memory block
            if (manager->blocks[i].size > size) {
                size_t remaining_size = manager->blocks[i].size - size;
                manager->blocks[i].size = size;
                MemoryBlock *new_block = &manager->blocks[manager->num_blocks++];
                new_block->address = (char *)manager->blocks[i].address + size;
                new_block->size = remaining_size;
                new_block->is_available = 1;
                manager->available_blocks++; // Add a new and available memory block
            }
            return manager->blocks[i].address;
        }
    }

    if (manager->num_blocks == MAX_BLOCKS) {
        printf("No more available blocks.\n");
        return NULL;
    }

    void *mem_start = (char *)manager->heap_start + manager->num_blocks * sizeof(MemoryBlock);
    if ((char *)mem_start + size > (char *)manager->heap_end) {
        printf("Not enough heap space.\n");
        return NULL;
    }

    manager->blocks[manager->num_blocks].address = mem_start;
    manager->blocks[manager->num_blocks].size = size;
    manager->blocks[manager->num_blocks].is_available = 0;
    manager->num_blocks++;
    manager->available_blocks--; // Reduce one available block

    return mem_start;
}

void my_free(MemoryManager *manager, void *ptr) {
    if (!ptr) return;
    for (int i = 0; i < manager->num_blocks; ++i) {
        if (ptr == manager->blocks[i].address) {
            manager->blocks[i].is_available = 1;
            manager->available_blocks++; // Add a new and available memory block

            // Merge adjacent free memory blocks
            if (i > 0 && manager->blocks[i - 1].is_available) {
                manager->blocks[i - 1].size += manager->blocks[i].size;
                for (int j = i; j < manager->num_blocks - 1; j++) {
                    manager->blocks[j] = manager->blocks[j + 1];
                }
                manager->num_blocks--;
                manager->available_blocks--;
            } else if (i < manager->num_blocks - 1 && manager->blocks[i + 1].is_available) {
                manager->blocks[i].size += manager->blocks[i + 1].size;
                for (int j = i + 1; j < manager->num_blocks - 1; j++) {
                    manager->blocks[j] = manager->blocks[j + 1];
                }
                manager->num_blocks--;
                manager->available_blocks--; 
            }
            return;
        }
    }
    printf("No matched block address for the given pointer in free() function.\n");
}

void print_memory_status(MemoryManager *manager) {
    printf("============================================\n");
    printf("Memory Blocks:\n");
    for (int i = 0; i < manager->num_blocks; ++i) {
        printf("address: %p, size: %zu, is_available: %d\n",
               manager->blocks[i].address,
               manager->blocks[i].size,
               manager->blocks[i].is_available);
    }
    printf("Total blocks: %d, Available blocks: %d\n", manager->num_blocks, manager->available_blocks);
    printf("============================================\n");
}
