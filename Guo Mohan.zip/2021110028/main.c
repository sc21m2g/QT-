#include <stdio.h>
#include "memory_management.h"

int main() {
    MemoryManager manager;
    init_mem_manager(&manager, 1000); // 1KB Heap Size

    printf("Initial Memory Status:\n");
    print_memory_status(&manager);

    int *arr = (int *)my_malloc(&manager, 10 * sizeof(int)); // Allocate an int array of 10;
    if (!arr) {
        printf("Memory allocation failed.\n");
        return -1;
    }

    for (int i = 0; i < 10; i++) {
        arr[i] = i * 2;
    }

    printf("Testing array content...\n");
    for (int i = 0; i < 10; i++) {
        printf("%d ", arr[i]);
    }
    printf("\n");

    printf("Memory Status after int array allocation:\n");
    print_memory_status(&manager);

    char *str = (char *)my_malloc(&manager, 20); // Allocate a char array of 20
    if (!str) {
        printf("Memory allocation failed.\n");
        return -1;
    }

    for (int i = 0; i < 20; i++) {
        str[i] = 'a' + i;
    }

    printf("Testing string content...\n");
    for (int i = 0; i < 20; i++) {
        printf("%c", str[i]);
    }
    printf("\n");

    printf("Memory Status after char array allocation:\n");
    print_memory_status(&manager);

    my_free(&manager, arr); // free the int array
    printf("Memory Status after freeing int array:\n");
    print_memory_status(&manager);

    my_free(&manager, str); // free the char array
    printf("Memory Status after freeing char array:\n");
    print_memory_status(&manager);

    int *arr2 = (int *)my_malloc(&manager, 10 * sizeof(int)); // Allocate an int array of 10;
    if (!arr2) {
        printf("Memory allocation failed.\n");
        return -1;
    }

    for (int i = 0; i < 10; i++) {
        arr2[i] = i;
    }

    printf("Testing array content...\n");
    for (int i = 0; i < 10; i++) {
        printf("%d ", arr2[i]);
    }
    printf("\n");

    printf("Memory Status after int array allocation:\n");
    print_memory_status(&manager);

    free(manager.heap_start);
    free(manager.blocks);

    printf("Finish successfully!");

    return 0;
}
