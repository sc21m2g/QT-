#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>

int main(int argc, char *argv[]) {
    if (argc != 2) {
        fprintf(stderr, "Usage: %s <megabytes>\n", argv[0]);
        return 1;
    }

    long long megabytes = atoll(argv[1]);
    long long bytes = megabytes * 1024 * 1024;
    char *data = (char *)malloc(bytes);

    if (data == NULL) {
        fprintf(stderr, "Failed to allocate memory\n");
        return 1;
    }

    // Fill with some data to ensure memory is used
    for (long long i = 0; i < bytes; i++) {
        data[i] = 'A';
    }

    printf("Allocated %lld MB of memory.\n", megabytes);

    // Run indefinitely or for a given time period
    while (1) {
        for (long long i = 0; i < bytes; i++) {
            data[i] = data[i];
        }
        sleep(1); // Sleep for 1 second to avoid overwhelming the CPU
    }

    free(data);
    return 0;
}
