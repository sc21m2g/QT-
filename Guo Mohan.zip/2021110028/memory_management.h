#ifndef MEMORY_MANAGEMENT_H
#define MEMORY_MANAGEMENT_H

#include <stdio.h>
#include <stdlib.h>

#define MAX_BLOCKS 1000

typedef struct MemoryBlock {
    void *address;
    size_t size;
    int is_available;
} MemoryBlock;

typedef struct MemoryManager {
    void *heap_start;
    void *heap_end;
    MemoryBlock *blocks;
    int num_blocks;
    int available_blocks;
} MemoryManager;

void init_mem_manager(MemoryManager *manager, size_t heap_size);

void *my_malloc(MemoryManager *manager, size_t size);

void my_free(MemoryManager *manager, void *ptr);

void print_memory_status(MemoryManager *manager);

#endif
